class  Infinity
{
public static void main(String s[])
{
Double  b1=2.4/0;
System.out.println(b1);
Double  b2=-2.4/0;
System.out.println(b2);


}

}