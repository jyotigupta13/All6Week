class  WrapperConstant
{
public static void main(String s[])
{
byte   b1=Byte.MIN_VALUE;
byte   b2=Byte.MAX_VALUE;
System.out.println(b1);
System.out.println(b2);
int  b3=Integer.MIN_VALUE;
int   b4=Integer.MAX_VALUE;
System.out.println(b3);
System.out.println(b4);
}

}