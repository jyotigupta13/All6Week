public class Concat 
{

   public static void main(String args[]) 
{
      String s = "Strings are immutable";
      s = s.concat(" all the time");
      System.out.println(s);
   }
}