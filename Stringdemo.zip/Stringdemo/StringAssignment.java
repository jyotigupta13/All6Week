class StringAssignment
{
1)static int wordCount(String s)

2)static int spaceCount(String s)

3)static int charCount(String s) //without spaces

4)static String reverse(String g)

5)static boolean palindrome(String s)

6)static String lTrim(String s) //remove left spaces

7)static String rTrim(String s) //remove right spaces

8)static String allTrim(String s) //equivalent to trim()  

9)static String squeeze(String s) //remove all spaces and convert whole String in one word

10)static int vowelCount(String s)

11)static int length(String s)

12)static void sequenceCount(String s)

13)static void frequencyCount(String) //print frequency wise order

14)static String changeCase(string s) //InDIa => iNdiA

15)static String singleOccurence(String s) //nniittiiin => nitin

16)static void sortedOrder(String s)

17)static String sortedWord(String)

18)static boolean find(String s1, String s2) //s2 in s1

19)static String replace(String s1, String s2,String s3) //if s2 is found in s1, replace s2 with s3

20)static boolean equals(String s1, String s2)

21)static void triangle1(String s1) 
{
d
du
duc
duca
ducat
}

22)static void triangle2(String s1) 
{
ducat
duca
duc
du
d
}

23)static void triangle3(String s1) 
{
ducat
   ucat
     cat
       at
         t
}

24)static void triangle4(String s1) 
{
ducatducat
duca   ucat
duc      cat
du         at
d             t
}

25)static int compare(String s1, String s2)


26)public static void  wordFrequencyCount(String s1) count the frequency of each word in a string
}

27)  solve the string  
public int  expression("10+20+20+20")

28)public int  BinaryToDecimal("10101010")
29)public void printNonRepetingFirstChar(String s)
30)public  void  reverseEachWord(String  s);
31)public  void   printAllWordsInReverseOrder(String  s)
32) boolean findDigitInString(String s)
33)int countDigitInString(String s)



