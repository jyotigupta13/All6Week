

public class Substring{
   public static void main(String args[]){
      String Str = new String("Welcome to Tutorials of String");

      System.out.print("Return Value :" );
      System.out.println(Str.substring(10) );

      System.out.print("Return Value :" );
      System.out.println(Str.substring(10, 15) );
   }
}