

public class ToLowerCase{
   public static void main(String args[]){
      String Str = new String("Welcome to Tutorials of String");

      System.out.print("Return Value :");
      System.out.println(Str.toLowerCase());
System.out.println(Str.toUpperCase());
   }
}