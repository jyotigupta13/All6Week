class Temp1
{
public static void main(String s[])
{

int x=10/0;

System.out.println("after the exception");

}



}