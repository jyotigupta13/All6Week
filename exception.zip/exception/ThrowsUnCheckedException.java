import  java.io.*;
import  java.io.*;

class   ThrowsUnCheckedException
{
void show()throws  ArithmeticException
{
System.out.println("base");
}

}

class  Child   extends  ThrowsException1
{

void show()throws  Exception
{
System.out.println("child");
}
}