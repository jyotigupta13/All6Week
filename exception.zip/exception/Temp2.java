//import  java.io.*;
class  Temp2
{
public static  void  main(String...  s)throws  IOException
{
int  a=System.in.read();
}



}
