class Temp
{
public static void main(String s[])throws ClassNotFoundException
{


Class.forName("sun.jdbc.odbc.jdbcodbc");
System.out.println("aaaaaaaa");

}



}