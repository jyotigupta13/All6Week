import java.io.*;
class Ps2
{


public static void main(String... s)
{
System.out.println("hello uncle via  out");
System.err.println("hay  aunt  via  err");
}
}

