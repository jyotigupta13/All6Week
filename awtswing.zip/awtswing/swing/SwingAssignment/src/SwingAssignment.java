/**
 * @(#)SwingAssignment.java
 *
 * SwingAssignment application
 *
 * @author 
 * @version 1.00 2010/5/19
 */
import javax.swing.*;
 
public class SwingAssignment {
    public static void main(String[] args) {
    	System.out.println("Hello World!");
    	//new NumToWordFrame();
    	//new SqrtNumFrame();
    	//new ArmstromgNum();
    	//new PalindromeNumFrame();
    	//new PrimeNumFrame();
    	//new ReverseNumFrame();
    	//new PowerNumFrame();
    	//new CalculatorFrame();
    	//Question.main();
    	//Shuffle.main();
    	//SwapImage.main();
    	//TicToc.main();
    	//EditorFrame.main();
    	//LayoutDemo.main();
    	BigNumMultiply.main();
    	
    	/*JFrame frame = new JFrame("Interger Field");
    	frame.add(new com.javax.swing.IntegerField());
    	frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    	frame.pack();
    	frame.setVisible(true);*/
    }
}
