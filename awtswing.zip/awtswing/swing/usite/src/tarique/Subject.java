package tarique;

public class Subject 
{
	public String pom;
	public String dm;
	public String cg;
}
