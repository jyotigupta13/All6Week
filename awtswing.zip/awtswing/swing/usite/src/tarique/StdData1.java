package tarique;

public class StdData1
{
	public String iname;
	public String icity;
	public String icode;
	public String univname;
	
}
