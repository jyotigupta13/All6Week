package tarique;

public class MarksData 
{
	public String course;
	public String sem;
	public String resulttype;
	public String subject;
	public String marks;
}
