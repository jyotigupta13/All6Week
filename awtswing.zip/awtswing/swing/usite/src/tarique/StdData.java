package tarique;

public class StdData 
{
		public int rollno;
		public String stdname;
		public String fathername;
		public String course;
		public String status;
		public String collegename;
		public String paddress;
		public String caddress;
		public String branch;
		public String city;
		public String dob;
		public String gender;
		public String mobile;
		public String email;
		public String session;
		
		//  Data Member for institutedetails table 
		
		
		
		
		
		
		
		
		
	
}
