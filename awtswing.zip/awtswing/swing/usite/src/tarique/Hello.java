package tarique;

import java.util.Hashtable;

public class Hello 
{
	String rollno;
	public void setRollno(String rollno) {
		this.rollno = rollno;
	}
	public Hashtable getResultData()
	{
		Hashtable e=new Hashtable();
		return e;
	}

}
