package tarique;

public class Marks 
{
	String course,sem,resulttype,subject,marks;

	public String getCourse() {
		return course;
	}

	public String getMarks() {
		return marks;
	}

	public String getResulttype() {
		return resulttype;
	}

	public String getSem() {
		return sem;
	}

	public String getSubject() {
		return subject;
	}

	public void setCourse(String course) {
		this.course = course;
	}

	public void setMarks(String marks) {
		this.marks = marks;
	}

	public void setResulttype(String resulttype) {
		this.resulttype = resulttype;
	}

	public void setSem(String sem) {
		this.sem = sem;
	}

	public void setSubject(String subject) {
		this.subject = subject;
	}
}
