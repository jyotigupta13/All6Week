import java.awt.*;

class DemoFrame1 extends Frame
{
DemoFrame1(String s,int  i,int  j)
{	
super(s);
setSize(i,j);
setVisible(true);
}
public static void main(String s[])
{
new DemoFrame1("First Frame",400,400);
new DemoFrame1("Second Frame",200,200);
}
}




//new DemoFrame1("frame first from main ");
//new DemoFrame1("frame first from main ");
//DemoFrame1 f=new DemoFrame1("frame first from main hjklhjklhj");
//f.setSize(400,400);
//f.setVisible(true);



